import { test } from "@playwright/test";
import { LoginPage } from "../pages/LoginPage";

import { WelcomePage } from "../pages/WelcomePage";
import { MyHomePage } from "../pages/MyHomePage";
import { MyLeadsPage } from "../pages/MyLeadsPage";
import { CreateLeadPage } from "../pages/CreateLeadpage";

import loginData from "../../data/loginData.json";

// Create a Playwright test
test("Test to verify Create Lead ${i + 1}", async ({ page }) => {

    // Create an object for the LoginPage
    let loginPageObj = new LoginPage(page);

    // Create an object for the WelcomePage
    let welcomePageObj = new WelcomePage(page);

    // Create an object for the MyHomePage
    let myHomePageObj = new MyHomePage(page);

    // Create an object for the MyLeadsPage
    let leadsPage = new MyLeadsPage(page);

    // Create an object for the CreateLeadPage
    let createLeadPage = new CreateLeadPage(page);

    // Navigate to the application URL
    await page.goto("/");

    // Perform login
    await loginPageObj.login();

    // Click the CRM/SFA option
    await welcomePageObj.clickCrmsfa();

    // Click the Leads option
    await myHomePageObj.clickLeads();

    // Click the Create Leads option
    await leadsPage.clickCreateCLeads();

    // Create a new lead with the given details
    await createLeadPage.createLead(
        "Testleaf",
        "Vineeth",
        "Rajendran"
    );

    // Wait for 5 seconds
    await page.waitForTimeout(5000);
});


