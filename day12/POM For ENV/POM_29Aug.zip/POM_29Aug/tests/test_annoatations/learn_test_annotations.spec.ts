import test from "@playwright/test";

//Annoations - To customixe the Execution

//only - to execute the particular testcase
//skip - to skip the testcase from execution
//fail - to purposely the testcase
//10 regresstion
// 1- Bug needs to be fix

//1 testcase - 30 secs   90 secs
// 70 sec






test.describe("Smoke Testcases", async()=>{

test.describe.configure({mode:"parallel"});

test("Test to verify login with Valid credentials", async({page})=>{
//test.slow();    
await page.goto("https://leaftaps.com/opentaps/control/main");
await page.locator(".id").click();
console.log("Valid credentials entered");
})

test("Test to verify login with InValid credentials", async({page})=>{
await page.goto("https://leaftaps.com/opentaps/control/main");
console.log("Valid Incredentials entered");
})

test("Test to verify login without credentials", async({page})=>{
await page.goto("https://leaftaps.com/opentaps/control/main");
console.log("credentials not entered");
})

})


//Diff between Playwright and Playwright Test\
//locate the element the interacting - Playwright
//Playwright Test - Executing the testcasee in a Customized 



