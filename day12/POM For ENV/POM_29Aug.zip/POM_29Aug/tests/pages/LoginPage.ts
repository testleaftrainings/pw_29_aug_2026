import {Page,Locator} from "@playwright/test"

export class LoginPage{
page:Page;
usernameField:Locator;
passwordField:Locator;
loginButton: Locator;

constructor(page:Page){
    this.page=page;
    this.usernameField=this.page.getByRole("textbox",{name:"Username"});
    this.passwordField=this.page.getByRole("textbox",{name:"Password"});
    this.loginButton=this.page.getByRole("button",{name:"Login"});
}

async login(){
    await this.usernameField.fill(process.env.LEAFTAPS_USERNAME!);
    await this.passwordField.fill(process.env.LEAFTAPS_PASSWORD!);
    await this.loginButton.click()
}
}