import { Page,Locator } from "@playwright/test";

export class MyLeadsPage{

    private CreateLeadButton: Locator;
    constructor (private page:Page){
    this.CreateLeadButton = this.page.getByRole("link",{name:"Create Lead"});
}

   async clickCreateCLeads() {

     await this.CreateLeadButton.click();

    }

}