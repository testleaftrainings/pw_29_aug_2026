import { Page,Locator } from "@playwright/test";

export class CreateLeadPage{

    private companyName: Locator;
    private firstName: Locator;
    private lastName: Locator;
    private createLeadButton: Locator;


  constructor (private page:Page){
        this.companyName = this.page.locator('#createLeadForm_companyName')

        this.firstName =this.page.locator("#createLeadForm_firstName")

        this.lastName = this.page.locator('#createLeadForm_lastName')

        this.createLeadButton = this.page.locator('[name="submitButton"]')
  }


async createLead(companyName: string, firstName: string,lastName: string) {

        await this.companyName.fill(companyName);
        await this.firstName.fill(firstName);
        await this.lastName.fill(lastName);
        await this.createLeadButton.click();

    }

}