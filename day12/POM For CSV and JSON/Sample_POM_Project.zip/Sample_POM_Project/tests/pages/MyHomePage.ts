import { Page,Locator } from "@playwright/test";

export class MyHomePage{

    private clickLeads: Locator;
    constructor (private page:Page){
    this.clickLeads = this.page.getByText("Leads",{exact:true});
}

   async home() {

     await this.clickLeads.click();

    }

}