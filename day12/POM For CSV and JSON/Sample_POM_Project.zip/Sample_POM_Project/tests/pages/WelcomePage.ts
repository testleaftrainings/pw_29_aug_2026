import { Page,Locator } from "@playwright/test";

export class WelcomePage{

    private crmsfaLink: Locator;
    constructor (private page:Page){
    this.crmsfaLink = this.page.getByText("CRM/SFA");
}

   async welcome() {

     await this.crmsfaLink.click();

    }

}