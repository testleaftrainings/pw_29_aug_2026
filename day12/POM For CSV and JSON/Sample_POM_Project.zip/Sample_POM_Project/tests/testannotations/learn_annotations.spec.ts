import test from "@playwright/test";
import { describe } from "node:test";

test.describe.configure({mode: "serial" })
test("Test to verify Login with valid credentials", async({page})=>{
    console.log("Test executed with valid credentials");
await page.goto("https://leaftaps.com/opentaps/control/main");

});

test("Test to verify Login with invalid credentials", async({page})=>{
    //test.slow();
    console.log("Test executed with invalid credentials");
await page.goto("https://leaftaps.com/opentaps/control/main");
//await page.locator("username").click();

});


test("Test to verify Login without inputs", async({page})=>{
console.log("Test executed with inputs");
await page.goto("https://leaftaps.com/opentaps/control/main");

});


