// Import the Playwright test function
import { test } from "@playwright/test";

// Import the LoginPage Page Object class
import { LoginPage } from "../pages/LoginPage";

// Import the WelcomePage Page Object class
import { WelcomePage } from "../pages/WelcomePage";

// Import the MyLeadsPage Page Object class
import { MyLeadsPage } from "../pages/MyLeadsPage";

// Import the CreateLeadPage Page Object class
import { CreateLeadPage } from "../pages/CreateLeadpage";

// Import the MyHomePage Page Object class
import { MyHomePage } from "../pages/MyHomePage";

// Import the file system module from Node.js
import fs from "fs";

// Import the CSV parser from csv-parse package
import { parse } from "csv-parse/sync";

// Read the CSV file as UTF-8 text
const csvData = fs.readFileSync("data/logindata.csv", "utf-8");

// Convert the CSV text into an array of JavaScript objects
const records: any = parse(csvData, {
    // Use the first row of the CSV as object property names
    columns: true,

    // Ignore empty rows from the CSV file
    skip_empty_lines: true
});

// Loop through each record available in the CSV file
for (let i = 0; i < records.length; i++) {

    // Create a separate Playwright test for each CSV record
    test(`test to verify create lead ${i + 1}-${records[i].username}`, async ({ page }) => {

        // Create an object for the LoginPage
        const loginPage = new LoginPage(page);

        // Create an object for the MyHomePage
        const homePage = new MyHomePage(page);

        // Create an object for the WelcomePage
        const welcomePage = new WelcomePage(page);

        // Create an object for the MyLeadsPage
        const leadsPage = new MyLeadsPage(page);

        // Create an object for the CreateLeadPage
        const createLeadPage = new CreateLeadPage(page);

        // Navigate to the URL available in the current CSV record
        await page.goto(records[i].url);

        // Login using username and password from the current CSV record
        await loginPage.login(
            records[i].username,
            records[i].password
        );

        // Handle the welcome page
        await welcomePage.welcome();

        // Handle the home page
        await homePage.home();

        // Click on the Create Leads option
        await leadsPage.clickCreateCLeads();

        // Create a new lead with the required details
        await createLeadPage.createLead(
            "Testleaf",
            "Vineeth",
            "Rajendran"
        );
    });
}