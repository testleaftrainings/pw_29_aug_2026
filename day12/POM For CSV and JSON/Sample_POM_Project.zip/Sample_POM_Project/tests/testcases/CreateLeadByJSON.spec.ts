// Import the Playwright test function
import { test } from "@playwright/test";

// Import the LoginPage Page Object class
import { LoginPage } from "../pages/LoginPage";

// Import the WelcomePage Page Object class
import { WelcomePage } from "../pages/WelcomePage";

// Import the MyLeadsPage Page Object class
import { MyLeadsPage } from "../pages/MyLeadsPage";

// Import the CreateLeadPage Page Object class
import { CreateLeadPage } from "../pages/CreateLeadpage";

// Import the MyHomePage Page Object class
import { MyHomePage } from "../pages/MyHomePage";

// Import the login test data from the JSON file
import loginData from "../../data/loginData.json";

// Loop through each login data record
for (let i = 0; i < loginData.length; i++) {

    // Create a test dynamically for each login data record
    test(`test to verify create lead ${i + 1}-${loginData[i].username}`, async ({ page }) => {

        // Create an object for the LoginPage
        const loginPage = new LoginPage(page);

        // Create an object for the MyHomePage
        const homePage = new MyHomePage(page);

        // Create an object for the WelcomePage
        const welcomePage = new WelcomePage(page);

        // Create an object for the MyLeadsPage
        const leadsPage = new MyLeadsPage(page);

        // Create an object for the CreateLeadPage
        const createLeadPage = new CreateLeadPage(page);

        // Navigate to the application URL
        await page.goto(loginData[i].url);

        // Login using the username and password from the JSON data
        await loginPage.login(
            loginData[i].username,
            loginData[i].password
        );

        // Handle the welcome page
        await welcomePage.welcome();

        // Handle the home page
        await homePage.home();

        // Click on the Create Leads option
        await leadsPage.clickCreateCLeads();

        // Create a new lead with the required details
        await createLeadPage.createLead(
            "Testleaf",
            "Vineeth",
            "Rajendran"
        );
    });
}