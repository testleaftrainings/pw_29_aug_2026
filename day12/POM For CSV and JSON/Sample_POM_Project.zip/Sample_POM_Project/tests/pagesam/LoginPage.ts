import { Page,Locator } from "@playwright/test";

export class LoginPage1{

    page:Page;
    loginButton: Locator;
     alertButton: Locator;

constructor (page:Page){
        this.page=page;
        this.loginButton = this.page.locator("[id='menuform:j_idt39']")
        //   menuform:m_overlay
        this.alertButton = this.page.locator("[id='menuform:m_overlay']")

}

async login1() {
        await this.loginButton.click();
        await this.alertButton.click();

    }

}