import { Page,Locator } from "@playwright/test";

export class WelcomePage1{
   page:Page;
   crmsfaLink: Locator;
    
   constructor (page:Page){
    this.page=page;
    this.crmsfaLink = this.page.locator("//span[text()='Show']").first();
}

   async welcome() {

     await this.crmsfaLink.click();
     await this.page.waitForTimeout(5000);

    }

}