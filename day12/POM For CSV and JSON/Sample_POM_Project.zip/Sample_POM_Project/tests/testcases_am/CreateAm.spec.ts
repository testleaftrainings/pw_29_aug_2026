import { test } from "@playwright/test";
import { LoginPage1 } from "../pagesam/LoginPage";
import { WelcomePage1 } from "../pagesam/WelcomePage";


test("test to verify create lead", async ({ page }) => {

    const loginPage = new LoginPage1(page);
   
    const welcomePage = new WelcomePage1(page);
  

    await page.goto("https://www.leafground.com/");

    await loginPage.login1();

    await welcomePage.welcome();

    

});