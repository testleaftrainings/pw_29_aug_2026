import { test, expect, type Page } from '@playwright/test';

const LOGIN_URL = 'https://leaftaps.com/opentaps/control/main';
const USERNAME = process.env.LEAFTAPS_USERNAME ?? '';
const PASSWORD = process.env.LEAFTAPS_PASSWORD ?? '';
const ALLOW_INVALID_PASSWORD_ATTEMPT = process.env.LEAFTAPS_ALLOW_INVALID_PASSWORD_TEST === 'true';

async function openLoginPage(page: Page): Promise<void> {
  await page.goto(LOGIN_URL);
  await expect(page.getByRole('heading', { name: 'Leaftaps Login' })).toBeVisible();
}

test.describe('Leaftaps Login Functionality', () => {
  test('LOGIN-01 - login page loads successfully', async ({ page }) => {
    // 1. Navigate to the login page and verify the visible login controls.
    await test.step('Open the login page', async () => {
      await openLoginPage(page);
      await expect(page).toHaveTitle('Leaftaps - TestLeaf Automation Platform');
      await expect(page.getByRole('textbox', { name: 'Username' })).toBeVisible();
      await expect(page.getByRole('textbox', { name: 'Password' })).toBeVisible();
      await expect(page.getByRole('button', { name: 'Login' })).toBeVisible();
      await expect(page.getByText('Welcome to Leaftaps Application - TestLeaf environment for automation engineering learning.')).toBeVisible();
    });
  });

  test('LOGIN-02 and LOGIN-09 - valid login reaches the authenticated landing page', async ({ page }) => {
    test.skip(!USERNAME || !PASSWORD, 'Set LEAFTAPS_USERNAME and LEAFTAPS_PASSWORD to run the authorized login test.');

    // 1. Enter authorized test credentials and submit the form.
    await test.step('Submit valid credentials', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Username' }).fill(USERNAME);
      await page.getByRole('textbox', { name: 'Password' }).fill(PASSWORD);
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Verify the authenticated landing state observed on the live application.
    await test.step('Verify the authenticated landing page', async () => {
      await expect(page.getByRole('heading', { name: 'Welcome Demo Sales Manager' })).toBeVisible();
      await expect(page.getByRole('link', { name: 'CRM/SFA' })).toBeVisible();
      await expect(page.getByRole('button', { name: 'Logout' })).toBeVisible();
      await expect(page).toHaveURL(/\/opentaps\/control\/login;jsessionid=[^/?#]+$/);
    });
  });

  test('LOGIN-03 - nonexistent username with valid password is rejected', async ({ page }) => {
    test.skip(!PASSWORD, 'Set LEAFTAPS_PASSWORD to run this check with the authorized test password.');

    // 1. Submit a nonexistent username with the authorized test password.
    await test.step('Submit the invalid username', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Username' }).fill('DefinitelyNoSuchLogin-Plan');
      await page.getByRole('textbox', { name: 'Password' }).fill(PASSWORD);
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Verify the observed user-facing rejection.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByText('following error occurred during login: User not found.')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Leaftaps Login' })).toBeVisible();
  });

  test('LOGIN-04 - valid username with invalid password is rejected (opt-in)', async ({ page }) => {
    test.skip(!USERNAME || !ALLOW_INVALID_PASSWORD_ATTEMPT,
      'Set LEAFTAPS_USERNAME and LEAFTAPS_ALLOW_INVALID_PASSWORD_TEST=true only when the test account is approved for an incorrect-password attempt.');

    // 1. Submit a deliberately incorrect password only when the environment permits it.
    await test.step('Submit one incorrect-password attempt', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Username' }).fill(USERNAME);
      await page.getByRole('textbox', { name: 'Password' }).fill('deliberately-invalid-password');
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Assert the observed error container without assuming unverified wording.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Leaftaps Login' })).toBeVisible();
  });

  test('LOGIN-05 - invalid username and password are rejected', async ({ page }) => {
    // 1. Submit values that do not contain account credentials.
    await test.step('Submit invalid credentials', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Username' }).fill('DefinitelyNoSuchLogin-Plan');
      await page.getByRole('textbox', { name: 'Password' }).fill('dummy-invalid-pass');
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Verify the observed rejection and unauthenticated form state.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByText('following error occurred during login: User not found.')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Leaftaps Login' })).toBeVisible();
  });

  test('LOGIN-06 - empty username and password display validation errors', async ({ page }) => {
    // 1. Submit the untouched form.
    await test.step('Submit empty credentials', async () => {
      await openLoginPage(page);
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Verify both actual validation messages.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByText('username was empty reenter')).toBeVisible();
    await expect(page.getByText('password was empty reenter')).toBeVisible();
  });

  test('LOGIN-07 - empty username is rejected', async ({ page }) => {
    // 1. Submit a non-empty dummy password with an empty username.
    await test.step('Submit with username omitted', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Password' }).fill('dummy-password');
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Verify the actual username-required error.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByText('username was empty reenter')).toBeVisible();
  });

  test('LOGIN-08 - empty password is rejected', async ({ page }) => {
    // 1. Submit a nonexistent username without a password.
    await test.step('Submit with password omitted', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Username' }).fill('DefinitelyNoSuchLogin-Plan');
      await page.getByRole('button', { name: 'Login' }).click();
    });

    // 2. Verify the actual password-required error.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByText('password was empty reenter')).toBeVisible();
  });

  test('LOGIN-11 - password field masks entered characters', async ({ page }) => {
    // 1. Confirm the password control is a password input and masks its value.
    await test.step('Inspect password masking', async () => {
      await openLoginPage(page);
      const passwordField = page.getByRole('textbox', { name: 'Password' });
      await expect(passwordField).toHaveAttribute('type', 'password');
      await passwordField.fill('non-sensitive-dummy');
      await expect(passwordField).toHaveValue('non-sensitive-dummy');
    });
  });

  test('LOGIN-12 - Enter submits the login form', async ({ page }) => {
    // 1. Submit an invalid login using Enter from the password field.
    await test.step('Submit using Enter', async () => {
      await openLoginPage(page);
      await page.getByRole('textbox', { name: 'Username' }).fill('DefinitelyNoSuchLogin-Plan');
      const passwordField = page.getByRole('textbox', { name: 'Password' });
      await passwordField.fill('dummy-invalid-pass');
      await passwordField.press('Enter');
    });

    // 2. Verify Enter submitted the form and the rejected login response is visible.
    await expect(page.getByText('The Following Errors Occurred:')).toBeVisible();
    await expect(page.getByText('following error occurred during login: User not found.')).toBeVisible();
  });
});
