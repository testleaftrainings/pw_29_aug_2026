# Leaftaps Login Functionality Test Plan

## Application Overview

Comprehensive user-facing test coverage for login page rendering, credential validation, password masking, form submission by button and Enter, and authenticated landing behavior on https://leaftaps.com/opentaps/control/main. The live page was inspected: title is “Leaftaps - TestLeaf Automation Platform”; visible heading is “Leaftaps Login”; inputs are labeled “Username” and “Password” (password input type); submit control is “Login”; submitting blank fields returns “username was empty reenter” and/or “password was empty reenter”; an unknown username returned “following error occurred during login: User not found.” Enter in the password field submitted the form and produced the same unknown-user error. No valid credentials were supplied, so successful login and the exact landing destination remain to be confirmed with an authorized dedicated test account.

## Test Scenarios

### 1. Leaftaps Login

**Seed:** ``

#### 1.1. LOGIN-01 - Login page loads successfully

**File:** `tests\login\login-page-loads.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh, unauthenticated browser context with no retained login session. Navigate to https://leaftaps.com/opentaps/control/main.
    - expect: The page loads without a browser/network error.
  2. Inspect the page heading, labeled fields, and submit control.
    - expect: The page title is “Leaftaps - TestLeaf Automation Platform” and the visible heading is “Leaftaps Login”.
    - expect: A text field labeled “Username”, a password field labeled “Password”, and a “Login” submit control are visible and enabled.
    - expect: The informational text “Welcome to Leaftaps Application - TestLeaf environment for automation engineering learning.” is visible.

#### 1.2. LOGIN-02 - Login accepts an authorized valid username and password

**File:** `tests\login\valid-login.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context. Obtain a dedicated, authorized non-production test account from the environment owner; do not hard-code credentials or use personal/production credentials.
    - expect: A valid test username and password are available securely for this run.
  2. Navigate to the login page, fill the “Username” and “Password” fields with the supplied valid test credentials, then activate “Login”.
    - expect: The login request succeeds and the user is authenticated.
    - expect: No login validation or authentication error is displayed.
  3. Inspect the resulting page and authenticated navigation state.
    - expect: The browser leaves the unauthenticated login state and displays the approved authenticated application landing page.

#### 1.3. LOGIN-03 - Invalid username with valid password is rejected

**File:** `tests\login\invalid-username-valid-password.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context. Use a deliberately nonexistent username and a valid password from a dedicated authorized non-production test account; do not use or expose production credentials.
    - expect: The invalid username is guaranteed not to identify an existing account.
  2. Navigate to the login page, enter the nonexistent username in “Username” and the authorized test password in “Password”, then select “Login”.
    - expect: Authentication is rejected and the user remains unauthenticated.
    - expect: Visible error feedback identifies the failed login; for an unknown username, the inspected application displayed “The Following Errors Occurred:” and “following error occurred during login: User not found.”
    - expect: The authenticated landing page is not shown.

#### 1.4. LOGIN-04 - Valid username with invalid password is rejected

**File:** `tests\login\valid-username-invalid-password.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context. Use the username of a dedicated authorized non-production test account and a deliberately incorrect password. Ensure the test account is not subject to lockout or rate-limit risk, or follow the environment owner's approved attempt policy.
    - expect: An authorized test username is available; the incorrect password is not the account's real password.
  2. Navigate to the login page, enter the authorized username and incorrect password, then select “Login”.
    - expect: Authentication is rejected and the user remains unauthenticated.
    - expect: Visible login error feedback is displayed; assert the user-facing error state without assuming exact copy until confirmed for the deployed environment.
    - expect: The authenticated landing page is not shown.

#### 1.5. LOGIN-05 - Invalid username and invalid password are rejected

**File:** `tests\login\invalid-credentials.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context. Use a deliberately nonexistent username and an arbitrary incorrect, non-sensitive password.
    - expect: The test inputs do not correspond to an existing account or contain real user secrets.
  2. Enter both invalid values and submit using “Login”.
    - expect: Authentication is rejected and the user remains unauthenticated.
    - expect: The page shows visible login error feedback. The inspected application returned “following error occurred during login: User not found.” for an unknown username.
    - expect: The authenticated landing page is not shown.

#### 1.6. LOGIN-06 - Empty username and password are rejected

**File:** `tests\login\empty-credentials.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context and open the login page.
    - expect: Both login fields are empty.
  2. Leave “Username” and “Password” blank and select “Login”.
    - expect: The login form is not accepted and the user remains unauthenticated.
    - expect: The page displays “The Following Errors Occurred:” and both “username was empty reenter” and “password was empty reenter”.
    - expect: The login form remains available for correction.

#### 1.7. LOGIN-07 - Empty username with non-empty password is rejected

**File:** `tests\login\empty-username.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context and open the login page.
    - expect: The username field is empty; use a non-sensitive dummy value in the password field.
  2. Leave “Username” blank, fill “Password” with a non-empty dummy value, and select “Login”.
    - expect: The user remains unauthenticated and the page displays “username was empty reenter” under “The Following Errors Occurred:”.
    - expect: The authenticated landing page is not shown.

#### 1.8. LOGIN-08 - Non-empty username with empty password is rejected

**File:** `tests\login\empty-password.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context and open the login page.
    - expect: The password field is empty; use a deliberately nonexistent username.
  2. Fill “Username” with a nonexistent username, leave “Password” blank, and select “Login”.
    - expect: The user remains unauthenticated and the page displays “password was empty reenter” under “The Following Errors Occurred:”.
    - expect: The authenticated landing page is not shown.

#### 1.9. LOGIN-09 - Successful login navigates to the expected landing page

**File:** `tests\login\authenticated-landing-page.spec.ts`

**Steps:**
  1. Precondition: Start in a fresh unauthenticated browser context. Obtain authorized dedicated non-production credentials and the expected authenticated landing URL or stable page landmark from the environment owner; this was not ascertainable without valid credentials during inspection.
    - expect: The test has an approved account and an explicit expected landing-page URL or stable user-facing landmark before execution.
  2. Log in with the approved valid credentials and inspect the resulting URL, page heading, and a stable authenticated-only landmark agreed with the environment owner.
    - expect: The resulting URL/page matches the approved authenticated landing destination.
    - expect: An authenticated-only page landmark is visible, and login controls/error feedback are no longer presented as the active unauthenticated page.
    - expect: The assertion does not depend on session IDs or other dynamic URL values.

#### 1.10. LOGIN-10 - Unsuccessful login attempts display appropriate error messages

**File:** `tests\login\login-error-messages.spec.ts`

**Steps:**
  1. Precondition: In a fresh unauthenticated context, submit a deliberately nonexistent username with a non-empty dummy password.
    - expect: A visible error summary “The Following Errors Occurred:” and message “following error occurred during login: User not found.” are displayed for the unknown-user case observed during inspection.
  2. In a separate fresh context, submit the authorized test username with an incorrect password, and then test each empty-field combination in its own fresh context.
    - expect: Every unsuccessful attempt remains unauthenticated and displays visible, relevant error feedback.
    - expect: For empty username/password combinations, the corresponding inspected messages are “username was empty reenter” and “password was empty reenter”.
    - expect: Do not assert unverified wording for valid-user/wrong-password; verify the deployed user-facing error exists without requiring identical copy unless the environment owner specifies it.

#### 1.11. LOGIN-11 - Password field masks entered characters

**File:** `tests\login\password-masking.spec.ts`

**Steps:**
  1. Precondition: Open the login page in a fresh unauthenticated browser context.
    - expect: The “Password” field is visible and editable.
  2. Inspect the password input type, then enter a non-sensitive dummy string into the field.
    - expect: The field is an input of type “password”.
    - expect: Entered characters are visually masked in the rendered control and are not displayed as readable plaintext in the page UI.
    - expect: The username field remains a normal text input.

#### 1.12. LOGIN-12 - Enter key submits the login form

**File:** `tests\login\enter-key-submit.spec.ts`

**Steps:**
  1. Precondition: Open the login page in a fresh unauthenticated browser context. Use a deliberately nonexistent username and non-sensitive incorrect dummy password.
    - expect: The login form is ready for input.
  2. Fill “Username” and “Password”, focus the password field, and press Enter instead of selecting “Login”.
    - expect: Enter submits the login form; the browser navigates/reloads to the login response state.
    - expect: The invalid attempt is rejected and visible error feedback is displayed. During inspection this behavior produced “following error occurred during login: User not found.”
    - expect: The authenticated landing page is not shown.
