export enum URLConstants {
    //adminURL = "https://login.salesforce.com/"
    adminURL = "https://orgfarm-6d28dcc693-dev-ed.develop.lightning.force.com/lightning/page/home"
}