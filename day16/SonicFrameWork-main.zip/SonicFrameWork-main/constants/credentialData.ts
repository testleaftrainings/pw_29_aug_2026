

/* const managerName: any = data.managerName
const commonUser: any = data.commonUser
const internalUser: any = data.internalUser
const externalUser: any = data.externalUser
const teamUser1: any = data.teamUser1
const teamUser2: any = data.teamUser2 */

export let credentials = {

    ADMINLOGIN: {
        username: "gauthami.vn@testleaf.com",
        password: "Qeagle@123"
    },
    USERLOGIN: {
        username: "dilipkumar.rajendran@testleaf.com",
        password: "TestLeaf@2025"
    }
};