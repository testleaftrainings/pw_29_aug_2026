import dotenv from 'dotenv';
import { FakerData } from '../../helpers/fakerUtils';
import { faker } from '@faker-js/faker';
import path from 'path';
dotenv.config({ path: '../../../data/apiData/oauthData.env' });
//require('dotenv').config({ path: './data/apiData/oauthData.env' });
// dotenv.config({
//     path: path.resolve(__dirname, "oauthData.env")
// });

console.log("CLIENT_ID:", process.env.CLIENT_ID ? "Loaded" : "Missing");
console.log("CLIENT_SECRET:", process.env.CLIENT_SECRET ? "Loaded" : "Missing");
console.log("SFUSERNAME:", process.env.SFUSERNAME ? "Loaded" : "Missing");
console.log("SFPASSWORD:", process.env.SFPASSWORD ? "Loaded" : "Missing");

export const oauthData = {
    grant_type: 'password',
    client_id: process.env.CLIENT_ID!,
    client_secret: process.env.CLIENT_SECRET!,
    username: process.env.SFUSERNAME!,
    password: process.env.SFPASSWORD!,
}
export const createLeaddata = {
    "FirstName": FakerData.getFirstName(),
    "LastName": FakerData.getLastName(),
    "Company": "Qeagle"
};

export const updateLeadData = {

    "FirstName": FakerData.getFirstName(),
    "Title": "SDET",
    "Street": FakerData.getStreet(),
    "City": FakerData.getCity(),
    "State": FakerData.getState(),
    "PostalCode": FakerData.getPinCode(),
    "Country": FakerData.getCountry(),
    "MobilePhone": FakerData.getMobileNumber(),
    "Email": FakerData.getEmail(),
    "Website": FakerData.getWebsite(),
}